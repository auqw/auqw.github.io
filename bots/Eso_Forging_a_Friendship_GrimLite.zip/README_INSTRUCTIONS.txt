
READ THE **INSTRUCTIONS** CAREFULLY 

PRE-WARNING: 
SAVE EVERY CHANGE YOU DO TO THE GBOT FILE or it will not pass on.
Must have completed 'The Final Form' quest in Tech Fortress (see aqwwiki for more info)

Information:

Farms all the items for Forge a Friendship quest by default.
If you don’t want to farm all the items change the SELECTED_NUMBER variable in Eso_Forging_a_Friendship_GrimLite.gbot from 1-7 to choose the item you want to farm. THEN **SAVE** THE BOT or else it won’t register. 
READ THE INSTRUCTIONS BELOW for more detail.

Instructions:

1. Place the Eso_Forging_a_Friendship_GrimLite.gbot and the Eso_Resources_Forging_a_Friendship folder in the /Bots folder (where all your other bots are placed) respectively.

2. Load the Eso_Forging_a_Friendship_GrimLite.gbot in GrimLite

**Optional**: {
2.1 Change the SELECTED_NUMBER to a integer from 1-7, or don’t change anything if you want to  collect all the items from the quest. 
WHEN YOU ARE DONE **SAVE** THE GBOT FILE or else it will not register.
}

3. Run the bot.