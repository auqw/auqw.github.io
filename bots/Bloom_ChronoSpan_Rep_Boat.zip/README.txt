If you're low level and can't kill a 2k HP mob instantly,
choose this:
- Bloom_ChronoSpan_Rep_CogsAndGears_Quests
- Approximately 50 secs

Otherwise, use this
- Bloom_ChronoSpan_Rep_GenEdGenerator_Quests
- Approximately 35 secs 