By Eso & Bloom, using Blooms Skillset
	
Tower of Doom: 1-10

Instructions:

1. Place the *Skillset-folder and the Storyline folder in Bots\

* - the Skillset folder must contain SkillsetV2.gbot

2. Edit the SkillsetV2.gbot file that is located in Bots\Skillset\
	- Change the Class-variables to your preferred Classes
	- Change the Skills if necessary

3. Save the SkillsetV2.gbot via Misc2-tab on the bot-editor (same filename in same folder)

4. Open Eso-Bloom_Tower-of-Doom_Rev.gbot located in the Storyline\Tower of Doom folder, and edit the optional part if you want

5. Save the file like you did on (3.)   

6. You are good to go. Enjoy