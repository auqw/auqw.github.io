Some more detailed instructions for those who are not sure on what to do, especially newbies to botting.

////STOP BOT TO CHANGE COMMAND LIST\\\\

||Q1: What does this bot do?||
A: Automatically buys you stuff on Vayle's Doom Merge (SDKA Merge) accordingly to your preference. You can choose what it buys, but by default it'll do Dark Energy -> Dark Spirit Orb.

||Q2: How do I change what the bot buys?||
A: Check the Command List. Scroll down. There is a label called "Start" with a few commands. Below it there are two grayish "change me". Between them there is "Goto label: Buy0". Double-click that and a new window (Raw Command Edit) will open. There is a line written "Label": "Buy0". Change that Buy0 to BuyX you want and click OK. Check "READ INSTRUCTIONS" to know what item each BuyX buys.

||Q3: What do I change 'Buy0' to if I want x?||
A: If you want to buy CORRUPT SPIRIT ORBS = Buy1. If you want to buy DARK SPIRIT ORBS and then CORRUPT SPIRIT ORBS = Buy2. If you want to buy OMINOUS AURA = Buy03. If you want to buy DIABOLICAL AURA = Buy04.

||Q4: The bot is bleeping! Why is it bleeping? It pisses me off :(||
A: Since it takes 10-30 minutes to finish it, I just assumed people will use it while doing other stuff on their PC and would like to be warned when it's finished. I thought about making a non-beeping version but... c'mon just turn the PC volume down.

||Q5: Why did the bot stop buying stuff?||
A: Bot stops when you do not have enough reagents to buy the stuff you want in the merge shop, or if you're using Buy5, you've reached the amount of items you want to buy.

||Q6: How do I use Buy5?||
A: Scroll to the bottom of the command list. Double-click "[95] Is in inventory: CHOOSE ITEM HERE, CHOOSE AMOUNT HERE". Raw Command Editor will open. 
In Value1, change CHOOSE ITEM HERE to the the item you want to buy (e.g. if you want to buy Diabolical Aura, change it to Diabolical Aura, without any typos and between quotation marks ""). Click OK.
In Value 2, change CHOOSE AMOUNT HERE to the amount of that item you want to buy (numerical value only, between quotation marks, e.g. "75"). Click OK.

Then, double-click "[97] Buy item fast: ITEM TO BE BOUGHT". 
In ItemName, change ITEM TO BE BOUGHT to the item you want to buy, the same item you put in Value1.

Should work like a charm then.

///////PLEASE NOTE\\\\\\\: if you want to buy diabolical auras, you'll require ominous auras. If you want to buy corrupt spirit orbs, you'll require dark spirit orbs.

If you want to convert your corrupt spirit orbs into diabolical aura, you must first do Corrupt Spirit Orb -> Ominous Aura and then Ominous Aura -> Diabolical Auras.

Still don't get it? Ask for help in autoquest.life's Discord server (ping me if I'm still there!) or just don't use it. Use Buy0/1/3/4 instead.