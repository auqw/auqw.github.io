How to use:
---------------------
1. Load the packet in Packet > Spammers > Load > NNg_Infinite_BackFlip_emote_fun_way_to_afk.xml
2. Change the delay to 900 (Increase it if u are getting disconnect)
3. other players will see u /backflip infinitly (but u might can't see it yourself) when u afk or even try to walk
---------------------
happy afk :))