Order of bots (to run)
1. Start with Arts_IceStormArena_Agro. You can keep running this bot until level 100 
but I recommend stopping it by level 50-75.
2. Run Arts_MountDoomSkull_Bot. This will finish the Mountdoomskull storyline for 
you and unlock Chaos Slayer.
3. Run Arts_ChaosREP_Bot and get Rank 10, buy Chaos Slayer (any will do) afterwards.
4. Complete the Darkovia storyline up until you unlock the quest "Sanguine"
from Constantin at /lycan. And run Weeb_Lycan_Rep and get Rank 10 to buy Lycan
5. You are free to grind whichever item you want. You may download more bots from our 
portal site: https://adventurequest.life

