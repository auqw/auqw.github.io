info.txt
1) Base file name
2) Server name
3) Room number
4) map name
5) <cell>,<pad>,<cell>,<pad>,...
6) aggromon packet1;aggromon packet2; ...
7) drop 1,drop 2, ...
8) quest 1,quest 2, ...
9) specific drop 1~quantity1,specific drop 2~quantity2

Drops and quests are optional.
If no drops, leave a blank line before filling in quests.
Do leave leave stray semicolons or commas.
See example info.txt
NEW: specific drops replace quest cannot be completed
if drop isn't whitelisted, generator assumes temp item
NEW 2: 
8) quest 1:item id1, ...