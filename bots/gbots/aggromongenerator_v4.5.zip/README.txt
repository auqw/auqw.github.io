info.txt
1) Base file name
2) Server name
3) Room number
4) map name
5) <cell>,<pad>,<cell>,<pad>,...
6) aggromon packet1;aggromon packet2; ...
7) drop 1,drop 2, ...
8) quest 1,quest 2, ...
9) specific drop 1~quantity1,specific drop 2~quantity2
10) y,n, ...

Drops and quests are optional.
If no drops, leave a blank line before filling in quests.
Do leave leave stray semicolons or commas.
See example info.txt
NEW: specific drops replace quest cannot be completed
if drop isn't whitelisted, generator assumes temp item
NEW 2: 
8) quest 1:item id1, ...
NEW 3: line 10 specifies quest list
if quest list is used at all, everything must be specified, otherwise assumes normal operation
y = quest will be in quest list
n = normal turn in
quest list quests will have check commands

		INSTRUCTIONS
1) Turn file extensions on.
2) Rename "info.example.txt" to just "info.txt"
3) Double click the aggromongenerator_v4.5.exe
4) You should now have 5 ShogunParagon bots
5) Check the formatting above and the info.txt and you'll figure out how it works.

YOU MUST HAVE AN "info.txt" IN THE SAME FOLDER AS THE AGGROMON GENERATOR FOR IT TO WORK.