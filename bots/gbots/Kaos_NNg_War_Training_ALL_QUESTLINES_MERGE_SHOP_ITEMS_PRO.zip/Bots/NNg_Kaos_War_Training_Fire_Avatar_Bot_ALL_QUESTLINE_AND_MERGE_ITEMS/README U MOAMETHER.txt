- These bots will grind all the questlines(storyline) in Fire Avatar for you (kaos bot) & grinding Merge shop items in FireAvatar merge shop (NNg's one).

- Run any of these since it's an auto detect bot (if you haven't complete the storyline but u run NNg's bot, it will autoload Kao's bot to complete it) and same thing when u run Kao's bot even tho you have complete the questline(storyline).

 Merge shop items can be customised inside the 2 bots (items quantity + class skillsets). (Double click the cmd to change the value).

 That's it!!! Have fun boating!!! Ping me in discord if there are any problems.