If you haven't finished the storyline of Trygve, run Kaos_Hollowborn_Trygve_GrimLiteRev.gbot

Otherwise, run NNg_Vindicator_Badge_Bot.gbot in order to get Vindicator Badge. (Since the /Trygve storyline needs to be completed b4 running this bot!)